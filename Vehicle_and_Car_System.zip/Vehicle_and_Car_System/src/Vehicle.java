public class Vehicle {
    String Brand;
    int Model;
    Vehicle(String Brand,int Model){
        this.Brand=Brand;
        this.Model=Model;
    }
}
class Car extends Vehicle{
    double price;
    Car(String Brand, int Model , double price){
        super(Brand, Model);
        this.price=price;
    }
    void show(){
        System.out.println("Brand="+ Brand+" Model="+Model+" Price="+price);

    }

}
