import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Catalog Name: ");
        String cname = sc.nextLine();
        System.out.print("Enter Catalog Location: ");
        String clocation = sc.nextLine();
        Catalog catalog = new Catalog(cname, clocation);
        while(true) {
            System.out.println("1. Add Album\n2. Search by Title\n3. Search by Naat-Kha\n4. Show All\n5. Exit");
            int choice = sc.nextInt();
            sc.nextLine();
            if (choice == 1) {
                System.out.print("Album ID: ");
                String id = sc.nextLine();
                System.out.print("Title: ");
                String title = sc.nextLine();
                System.out.print("Naat-Kha: ");
                String naatKha = sc.nextLine();
                System.out.print("Release Date: ");
                String release = sc.nextLine();
                NaatAlbum album = new NaatAlbum(id, title, naatKha, release);
                catalog.addAlbum(album);
            }
            else if (choice == 2) {
                System.out.print("Title to search: ");
                String ttl = sc.nextLine();
                catalog.searchByTitle(ttl);
            }
            else if (choice == 3) {
                System.out.print("Naat-Kha to search: ");
                String nk = sc.nextLine();
                catalog.searchByNaatKha(nk);
            }
            else if (choice == 4) {
                catalog.showAllAlbums();
            }
            else if (choice == 5) break;
        }
        sc.close();
    }
}
