public class AlbumNode {
    NaatAlbum album;
    AlbumNode next;
    public AlbumNode(NaatAlbum album) {
        this.album = album;
        this.next = null;
    }
}
    class Catalog {
        private String catalogName;
        private String catalogLocation;
        private AlbumNode head;
        public Catalog(String name, String location) {
            this.catalogName = name;
            this.catalogLocation = location;
            this.head = null;
        }
        public void addAlbum(NaatAlbum album) {
            if (findAlbum(album.getAlbumId()) != null) {
                System.out.println("Duplicate album ID not allowed.");
                return;
            }
            AlbumNode node = new AlbumNode(album);
            node.next = head;
            head = node;
        }
        public NaatAlbum findAlbum(String albumId) {
            AlbumNode current = head;
            while (current != null) {
                if (current.album.getAlbumId().equals(albumId))
                    return current.album;
                current = current.next;
            }
            return null;
        }

        public void searchByTitle(String title) {
            AlbumNode current = head;
            while (current != null) {
                if (current.album.getTitle().equalsIgnoreCase(title)) {
                    current.album.displayAlbum();
                }
                current = current.next;
            }
        }
        public void searchByNaatKha(String naatKha) {
            AlbumNode current = head;
            while (current != null) {
                if (current.album.getNaatKha().equalsIgnoreCase(naatKha)) {
                    current.album.displayAlbum();
                }
                current = current.next;
            }
        }
        public void showAllAlbums() {
            System.out.println("Catalog: " + catalogName + ", Location: " + catalogLocation);
            AlbumNode current = head;
            while (current != null) {
                current.album.displayAlbum();
                current = current.next;
            }
        }
    }
