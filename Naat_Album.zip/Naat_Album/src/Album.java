import java.util.Scanner;
public class Album {
        private String albumId;
        private String title;
        private String naatKha;
        private String releaseDate;
        public Album(String albumId, String title, String naatKha, String releaseDate) {
            this.albumId = albumId;
            setTitle(title);
            setNaatKha(naatKha);
            this.releaseDate = releaseDate;
        }
        public String getAlbumId() { return albumId; }
        public void setAlbumId(String albumId) { this.albumId = albumId; }
        public String getTitle() { return title; }
        public void setTitle(String title) {
            this.title = title.replaceAll("[^a-zA-Z0-9 ]", "").trim();
        }
        public String getNaatKha() { return naatKha; }
        public void setNaatKha(String naatKha) {
            this.naatKha = naatKha.replaceAll("[^a-zA-Z ]", "").trim();
        }
        public String getReleaseDate() { return releaseDate; }
        public void setReleaseDate(String releaseDate) { this.releaseDate = releaseDate; }
        public void displayAlbum() {
            System.out.println("ID: " + albumId + ", Title: " + title + ", Naat-Kha: " + naatKha + ", Release: " + releaseDate);
        }
    }
    class NaatAlbum extends Album {
        public NaatAlbum(String albumId, String title, String naatKha, String releaseDate) {
            super(albumId, title, naatKha, releaseDate);
        }
    }


