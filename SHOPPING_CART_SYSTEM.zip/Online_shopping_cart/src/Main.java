import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        Shopping_Cart cart=new Shopping_Cart();
        System.out.println("===Online Shopping Cart===");
        for(int i=1;i<=3;i++){
            System.out.println("\nEnter details for Product " + i + ":");
            System.out.println("Enter ProductID=");
            int id= sc.nextInt();
            sc.nextLine();
            System.out.println("Enter Product Name=");
            String nam=sc.nextLine();
            System.out.println("Enter Product Price=");
            Double pric=sc.nextDouble();
            sc.nextLine();
            System.out.println("Enter Product Description =");
            String desc=sc.nextLine();
            Product p=new Product(id,nam,pric,desc);
            cart.addProduct(p);
            cart.displayCart();

        }
    }
}