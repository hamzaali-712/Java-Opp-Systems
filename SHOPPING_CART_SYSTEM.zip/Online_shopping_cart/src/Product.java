public class Product {
    private  int productID;
    private String name;
    private double price;
    private String description;
    public Product(int productId, String name, double price, String description) {
        if (price < 0) {
            System.out.println("Price cannot be negative!");
        }
        this.productID=productId;
        this.name=name;
        this.price=price;
        this.description=description;}

    public int getProductID() {
        return productID;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        if(price<0){
            System.out.println("Price cannot be negative!");
        }
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    public void display(){
        System.out.println("ProductID="+productID+" Name="+name+"Price="+price+"Description="+description);
    }
}
