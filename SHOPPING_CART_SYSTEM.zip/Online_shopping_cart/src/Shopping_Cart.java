public class Shopping_Cart {
    private Product product1;
    private Product product2;
    private Product product3;
    public void addProduct(Product product) {
        if (product.getPrice() <= 0) {
            System.out.println("Error: Invalid product price for " + product.getName());
            return;
        }
        if (product1 == null) {
            product1 = product;
            System.out.println(product.getName() + " added to cart.");
        } else if (product2 == null) {
            product2 = product;
            System.out.println(product.getName() + " added to cart.");
        } else if (product3 == null) {
            product3 = product;
            System.out.println(product.getName() + " added to cart.");
        } else {
            System.out.println("Cart is full! Remove a product first.");
        }
    }

    public double calculateTotal() {
        double total = 0;
        if (product1 != null){
            total += product1.getPrice();
        }
        if (product2 != null) {
            total += product2.getPrice();
        }
        if (product3 != null){
            total += product3.getPrice();
        }
        return total;
    }
    public void displayCart() {
        System.out.println("\n--- Shopping Cart Contents ---");

        if (product1 != null) {
            product1.display();
        }
        if (product2 != null) {
            product2.display();
        }
        if (product3 != null) {
            product3.display();
        }

        System.out.println("Total Price: $" + calculateTotal());
    }
}
