public class Owner {
    private String ownerName;
    Owner(String ownerName){
        this.ownerName=ownerName;
    }
    public String getOwnerName(){
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }
}
class House{
    private String address;
    private Owner owner;
    House(String address,Owner owner){
        this.address=address;
        this.owner=owner;
    }
    void show(){
        System.out.println("House Address="+address);
        System.out.println("Owner Name="+owner.getOwnerName());
    }
        }
