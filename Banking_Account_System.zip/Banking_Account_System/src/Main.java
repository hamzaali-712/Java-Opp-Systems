import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Acount Number=");
        int no= sc.nextInt();
        System.out.println("Enter Initial Balance=");
        double ibal=sc.nextDouble();
        BankAccount b1=new BankAccount(no,ibal);
        System.out.println("Enter amount that you want to deposit");
        double dep=sc.nextDouble();
        b1.deposit(dep);
        System.out.println("Enter amount you want to withdraw=");
        double wi= sc.nextDouble();
        b1.withdraw(wi);
        b1.show();
        //TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
        // to see how IntelliJ IDEA suggests fixing it.
    }
}