public class BankAccount {
    private int ac_no;
    private double balance;
    static String bankName="National Bank";
    BankAccount(int ac_no,double balance){
        this.ac_no=ac_no;
        this.balance=balance;
    }
    public int getAc_no() {
        return ac_no;
    }
    public double getBalance() {
        return balance;
    }
    public void deposit(double amount){
            this.balance=balance+amount;
            System.out.println("Amount Deposit="+amount);
    }
    public void withdraw(double amount){
        if (amount<=balance){
            this.balance=balance-amount;
            System.out.println("Amount Withdrawal="+amount);
        }
        else {
            System.out.println("Insufficient Funds");
        }
    }
    static void showBankName(){
        System.out.println("Welcome to our "+bankName);
    }
    void show(){
        System.out.println("Account="+ac_no+" Blanace="+balance);
    }
}
