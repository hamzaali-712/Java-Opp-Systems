import java.util.Scanner;
public class Employee {
    private String name;
    private  double salary;
    static int count=0;
    Employee(String name, double salary){
        this.name=name;
        this.salary=salary;
        count++;
    }
    public String getName(){
        return name;
    }

    public double getSalary() {
        return salary;
    }

    public void setName(String name) {
        this.name = name;
    }


    public void setSalary(double salary) {
        this.salary = salary;
    }
    static void setCount(){
        System.out.println("Total Employee="+ count);
    }
    void display(){
        System.out.println("Employee:"+ name +" Salary=" +salary);

    }
}
