import java.util.Scanner;//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Employee 1 Name");
        String name1= sc.nextLine();
        System.out.println("Enter Employee Salary");
        double sal1= sc.nextDouble();
        sc.nextLine();
        System.out.println("Enter 2nd Employee Name ");
        String name2= sc.nextLine();
        System.out.println("Enter 2nd Employee Salary");
        double sal2= sc.nextDouble();
        Employee e1=new Employee(name1,sal1);
        Employee e2=new Employee(name2,sal2);
        e1.display();
        e2.display();
        Employee.setCount();
        sc.close();

    }
}