import java.util.Scanner;
public class Student {
    private String name;
    private int rollno;
    private String dept;
    Student(){
        this("Unknown",0,"None");
    }
    Student(String name,int rollno, String dept){
        this.name=name;
        this.rollno=rollno;
        this.dept=dept;
    }
    Student(Student s){
        this.name=s.name;
        this.rollno=s.rollno;
        this.dept=s.dept;
    }
    void show(){
        System.out.println("Name"+name+"Roll number=" +rollno+" Department="+dept);
    }
}
