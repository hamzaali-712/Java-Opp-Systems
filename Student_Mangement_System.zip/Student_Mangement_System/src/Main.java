import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Student Name=");
        String name=sc.nextLine();
        System.out.println("Enter Rollno=");
        int rollno =sc.nextInt();
        sc.nextLine();
        System.out.println("Enter Department=");
        String dept=sc.nextLine();
        Student s2=new Student(name,rollno,dept);
        Student s1=new Student(s2);
        s2.show();
        s1.show();
        sc.close();
    }
}